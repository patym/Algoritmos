package controller;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import model.Hashtable;
import model.Route;

public class App {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Hashtable table = new Hashtable();

		try {
			FileReader routes = new FileReader("data/routes.txt");
			Scanner input = new Scanner(routes).useDelimiter("[,\n]");
			input.nextLine(); 

			while(input.hasNext()){
				Route route = new Route(input.next());
				input.next(); 
				route.setShortName(input.next());
				route.setLongName(input.next());
				input.next();
				route.setType(input.nextInt());
				input.next();
				route.setColor(input.next());
				route.setTextColor(input.next());
				
				String line = "Key: " + route.getShortName() + "\n"
							+ "Name: " + route.getLongName() + "\n" 
							+ "Type: " + route.getType() + "\n" 
							+ "Color: " + route.getColor() + "\n" 
							+ "Text Color: " + route.getTextColor() + "\n";
							
				System.out.println(line);

				String key = route.getShortName();
                String value = route.getLongName();
                
                table.put(key, value); 
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				           
	}

}
