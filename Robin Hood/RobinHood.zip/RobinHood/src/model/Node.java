package model;

public class Node {
	private final String key;
	private String value;
	private int hCode;
	private int probe;
	private boolean removed;
	
	/** Node constructor
	 * @param k : Key
	 * @param v : Value
	 * @param hc : HashCode
	 */
	public Node(String k, String v, int hc) {
		this.key = k;
		this.value = v;
		this.hCode = hc;
		this.removed = false;
	}
	
	// GETTERS
	public String getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}

	public int getHCode() {
		return hCode;
	}
	
	public int getProbe() {
		return probe;
	}

	public boolean isRemoved() {
		return removed;
	}
	
	// SETTERS	
	public void setValue(String value) {
		this.value = value;
	}

	public void setHCode(int hCode) {
		this.hCode = hCode;
	}
	
	public void setProbe(int probe) {
		this.probe = probe;
	}
	
	public void setRemoved(boolean removed) {
		this.removed = removed;
	}
	
	// UTIL
	public void incrementProbe(){
		this.probe++;
	}
	
	public void decrementProbe(){
		this.probe--;
	}
}
