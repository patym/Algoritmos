package model;

public class Route {
	private String id;
	private String shortName;
	private String longName;
	private int type;
	private String color;
	private String textColor;
	
	// CONSTRUCTOR
	public Route(String id) {
		this.id = id;
	}

	// GETTERS
	public String getId() {
		return id;
	}

	public String getShortName() {
		return shortName;
	}

	public String getLongName() {
		return longName;
	}

	public int getType() {
		return type;
	}

	public String getColor() {
		return color;
	}

	public String getTextColor() {
		return textColor;
	}

	// SETTERS
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public void setLongName(String longName) {
		this.longName = longName;
	}

	public void setType(int type) {
		this.type = type;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setTextColor(String textColor) {
		this.textColor = textColor;
	}
	
}
