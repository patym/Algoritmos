package model;

public class Hashtable {
	private int size = 10;
	private Node[] table = new Node[size];
	private int count = 0;

	public void put(String key, String value) {
		if (count == table.length){
			rehash();
		}
		
		int hCode = hash(key);
		//System.out.println("    Key: " + key + " - HashCode: " + hCode + " - Counter: " + count + "\n");
		Node newEntry = new Node(key, value, hCode);
		int index = hCode & 0x7ffffff% table.length;
		
		while (table[index] != null){
			if (newEntry.getProbe() < table[index].getProbe() || table[index].isRemoved()){
				if(table[index].isRemoved()) {
					table[index].setValue(newEntry.getValue());
					table[index].setRemoved(false);
					return;
				} else {
					swap(newEntry, table[index]);
				}
			} else {
				newEntry.incrementProbe();
			}
			index = index + 1 % table.length;
		}
		table[index] = newEntry;
		count ++;
	}
	
	public String get(String key) {
		int hCode = hash(key);
		int index = hCode & 0x7ffffff % table.length;
		int probe = 0;
		
		while (count < table.length && probe <= table[index].getProbe()) {
			if(table[index].getHCode() == hCode && table[index].getKey() == key){
				if(table[index].isRemoved()){
					return null; 
				}
				return table[index].getValue();
			}		
			index = index + 1 % table.length;
			probe++;
		}
		return null;	
	}
	
	public void remove(String key){
		Node element = searchNode(key);
		if (!element.isRemoved()) {
			element.setRemoved(true);;
		}
	}
	
	public Node searchNode(String key) {
		int hCode = hash(key);
		int index = hCode & 0x7ffffff % table.length;
		int probe = 0;
		
		while (count < table.length && probe <= table[index].getProbe()) {
			if(table[index].getHCode() == hCode && table[index].getKey() == key){
				return table[index];
			}		
			index = index + 1 % table.length;
		}
		return null;	
	}
		
	private void swap(Node newEntry, Node oldElement) {
		Node aux = newEntry;
		newEntry = oldElement;
		oldElement = aux;		
	}
	
	private int hash(String key) {
		int prime = 31;
		for (char c : key.toCharArray()) {
			prime = (prime + c) << 4 + (c & 0x0F);
		}
		return prime;
	}
	
	private void rehash() {
		Node[] auxTable = table;	
		size = size*2;
		count = 0;
		table = new Node[size];
	
		for (Node x : auxTable){
			//if(x != null){
				put(x.getKey(), x.getValue());
			//}
		}
	}
}
