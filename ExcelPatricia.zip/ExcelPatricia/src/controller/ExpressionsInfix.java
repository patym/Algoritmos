package controller;
import java.util.Scanner;
import java.util.regex.Pattern;

import model.Stack;

public class ExpressionsInfix {
	
		private static final String operators = "-+*/(";
	    private static final int[] precedence = {1, 1, 2, 2, 3};
	    private static final Pattern tokens = Pattern.compile("\\d+\\.\\d*|\\d+|" + "\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*" + "|[" + operators + "]");

	public Stack invert(Scanner infix){
		Scanner e = infix;
		Stack<String> posfixStack = new Stack<>();
		Stack<String> operatorStack = new Stack<>();
		
		while(e.hasNext()){
			if(e.hasNextDouble()){
				posfixStack.push(e.next());
			}
			if(isOperator(e.next())){ // Se o próximo for um operador, entra no if aqui
				if(!operatorStack.isEmpty()){ // Se o operatorStack não estiver vazio, executa o if
					if(precedence(operatorStack.peek()) >= precedence(e.next())){ //se o operador no operatorStack for maior ou igual que o operador do infix...
						posfixStack.push(operatorStack.pop());	// ...transfere ele pro posfixStack
						operatorStack.push(e.next()); // 
					} else {
						operatorStack.push(e.next());
					}
				} else {
					operatorStack.push(e.next());
				}
			}
		}
		return posfixStack;		
	}

    private static boolean isOperator(String ch) {
        return operators.indexOf(ch) != -1;
    }

    private static int precedence(String op) {
        return precedence[operators.indexOf(op)];
    }
}
