package controller;
import java.util.Scanner;

import model.Stack;

public class Expressions {
	
	public Double calcule(Scanner e){
		Stack<Double> stack = new Stack<>();		
		
		while (e.hasNext()) {
			if(e.hasNextDouble()) {
				stack.push(e.nextDouble());
			}
			
			if(e.hasNext("[+-/*]")) {
				double rhs = stack.pop();
				double lhs = stack.pop();
				
				switch(e.next()) {
					case "/":
						stack.push(lhs / rhs);
						break;
					case "*":
						stack.push(lhs * rhs);
						break;
					case "+":
						stack.push(lhs + rhs);
						break;	
					case "-":
						stack.push(lhs - rhs);
						break;					
				}				
			}			
		}		
		return stack.pop();		
	}
}