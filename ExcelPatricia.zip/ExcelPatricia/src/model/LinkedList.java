package model;

public class LinkedList<T> implements Iterable<T>{

	private Node<T> head;
	private Node<T> tail;
	
	private class ListIterator implements Iterator<T> {

		private Node<T> current = null;
		
		@Override
		public boolean hasNext() {
			if (current == null)
				return head != null;
			else
				return current.getNext() != null;
		}

		@Override
		public T next() {
			if (current == null)
				current = head;
			else
				current = current.getNext();
			return current.getValue();
		}

		@Override
		public void append(T value) {
			if (current == null)
				throw new IllegalStateException("Use next()!");
			Node<T> element = new Node<>(value);
			Node<T> next = current.getNext();
			element.setNext(next);
			element.setPrevious(current);
			current.setNext(element);
			if (next == null) {
				tail = element;
			} else {
				next.setPrevious(element);
			}
		}

		@Override
		public void insert(T value) {
			if (current == null)
				throw new IllegalStateException("Use next()!");
			Node<T> element = new Node<>(value);
			Node<T> previous = current.getPrevious();
			element.setNext(current);
			element.setPrevious(previous);
			current.setPrevious(element);
			if (current == null) {
				head = element;
			} else {
				current.setNext(element); 
			}
		}		
	}
	
	public void addFirst(T value) {
		Node<T> element = new Node<>(value);
		
		if (head == null) {
			tail = element;
		} else {
			element.setNext(head);
			head.setPrevious(element);
		}
		
		head = element; 
	}

	public void append(T value) {
		Node<T> element = new Node<>(value);
		
		if (this.head == null) {
			this.head = element;
		} else {
			element.setPrevious(this.tail);
			this.tail.setNext(element);
		}
		
		this.tail = element;		
	}

	public boolean isEmpty() {
		return (head == null);
	}

	public T getLast() {
		if (isEmpty()){
			return null;
		} else{
			return tail.getValue();
		}		
	}

	public void removeLast() {
		if (isEmpty()) {
			return;
		}		
		if (tail == head) {
			tail = head = null;			
		} else {
			Node<T> previous = tail.getPrevious();
			previous.setNext(null);
			tail = previous;			
		}		
	}
	
	public Iterator<T> iterator(){
		return new ListIterator();
	}
}
