package model;

public class Node<T> {
	
	private T value;
	private Node<T> previous;
	private Node<T> next;
	
	public Node(T value) {
		this.value = value;
	}
	
	public void setPrevious(Node<T> element) {
		this.previous = element;
	}

	public void setNext(Node<T> element) {
		this.next = element;
	}
	
	public T getValue() {
		return value;
	}
	
	public Node<T> getPrevious(){
		return previous;
	}
	
	public Node<T> getNext(){
		return next;
	}
	
}
