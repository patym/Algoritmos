package model;

public class NodeMatrix<T> {
	
	private int row;
    private int col;
    private T value;
    private NodeMatrix<T> down;
    private NodeMatrix<T> right;

    public NodeMatrix(int row, int col, T value){
	    this.row = row;
	    this.col = col;
	    this.value = value;
	}
    
    public void setDown(NodeMatrix<T> element) {
		this.down = element;
	}
    
	public void setRight(NodeMatrix<T> element) {
		this.right = element;
	}	
	
	public NodeMatrix<T> getDown(){
		return down;
	}
	
	public NodeMatrix<T> getRight(){
		return right;
	} 
	
	public T getValue(){
		return value;
	}
	
	public void setValue(T value){
		this.value = value;
	}
	
	public int getRow(){
		return row;
	}
	
	public int getCol(){
		return col;
	}
}
