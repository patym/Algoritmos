package model;
public interface Iterator<T>
	extends java.util.Iterator<T>
{
	void insert(T value);
	void append(T value);
}
