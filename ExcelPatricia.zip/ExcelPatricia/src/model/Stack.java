package model;
public class Stack<T> {
	
	private LinkedList<T> list = new LinkedList<>();
	
	public void push(T valor){
		list.append(valor);	
	}
	
	public boolean isEmpty(){ 
		return list.isEmpty();
	}
	
	public T peek(){
		return list.getLast();
	}
	
	public T pop(){		
		T value = peek();
		list.removeLast();
		return value;		
	}
	
	public static void main(String... args) {
		Stack<Integer> stack = new Stack<>();
		stack.push(1);
		stack.push(2);
		stack.push(3);
		System.out.println(stack.pop());
		System.out.println(stack.pop());
		System.out.println(stack.pop());
	}
}
