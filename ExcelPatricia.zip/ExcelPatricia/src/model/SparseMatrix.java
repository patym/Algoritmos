package model;

public class SparseMatrix<T> {
	
	private NodeMatrix<T> firstNode;
	private int limitRow;
	private int limitCol;
	private NodeMatrix<T> lastRow;
	private NodeMatrix<T> lastCol;
	
	public SparseMatrix() {
		limitRow = 5;
		limitCol = 5;
		NodeMatrix<T> lastRow = new NodeMatrix<>(limitRow + 1, 0, null);
		NodeMatrix<T> lastCol = new NodeMatrix<>(0, limitCol + 1, null);
		firstNode = new NodeMatrix<T>(0, 0, null);
	}
	
	 public T getValueMatrix(int row, int col){
		NodeMatrix<T> current;
	    T value = null;

	    current = findNode(row, col);

	    if (current != null) { //if a NodeMatrix was found
	    	value = current.getValue(); //the value is returned		    
	    } 
	    return value;
	  }
	 
	 public void setValueMatrix(int row, int col, T entryValue){

	    NodeMatrix<T> above;
	    NodeMatrix<T> previous = null;
	    NodeMatrix<T> current;
	    T oldValue;

	    current = findNode(row, col);

	    if (current != null) {
	    	current.setValue(entryValue);
	      if (current.getValue() == null) {			// if it changes that value to 0, it removes that     
	        current.setDown(findDown(row, col)); // bypasses that NodeMatrix in its
	        current.setRight(findRight(row, col));// bypasses the NodeMatrix in its row
	      } 
	      if (isRowEmpty(row)) { // if that row is now empty, it will remove it
	    	  deleteRow(row);
	      } 
	      if (isColEmpty(col)) { // if that column is now empty, it will remove it.
	        	deleteCol(col);
	      }
	    } else {
	    // if that NodeMatrix does not yet exist, it will create it
	      if (findNode(row, 0) == null) { // if the row does not exist, it is
	    	 createRow(row);
	      } 
	      if (findNode(0, col) == null) { // if the column does not exist, it is
	    	  createCol(col);
	      }
	      current = firstNode;
	      // traverses the linked list until current is pointing to the NodeMatrix after the
	      // NodeMatrix we
	      // wish to create will be, and prev points to the NodeMatrix before it
	      while (current.getRow() < row) {
	        current = current.getDown();
	      }
	      while (current.getCol() < col) {
	        previous = current;
	        current = current.getRight();
	      }
	      // makes the new NodeMatrix, pointed to by the NodeMatrix to the left of it, pointing to the NodeMatrix to the right and below it
	      NodeMatrix<T> newNode = new NodeMatrix<>(row, col, entryValue);
	      newNode.setDown(current.getDown());
	      newNode.setRight(previous.getRight());
	      previous.setRight(newNode);
	      current.setDown(newNode);

	      // creates a link from the NodeMatrix above it to the NodeMatrix just created
	    }
	}

	 private NodeMatrix<T> findNode(int row, int col) {

	    NodeMatrix<T> current = firstNode;
	    NodeMatrix<T> found = null; // the NodeMatrix to be returned. Remains null if not found.

	    while (current.getRow() < row) {
	      // moves to the row we wish to find
	      current = current.getDown();
	    }
	    if (current.getRow() == row) { // if that row is present, traverses to the column we
	    // wish to find
	      while (current.getCol() < col) {
	        current = current.getRight();
	      }
	      if (current.getCol() == col) { // if that column exists, then we have found the
	      // NodeMatrix and return it.
	      found = current;
	      }
	    }
	    return found;
	 }
	
	 private NodeMatrix<T> findDown(int row, int col) {
		NodeMatrix<T> current = firstNode;
		NodeMatrix<T> prev = null;
		// traverses right across the linked list to the correct column first
		while (current.getCol() < col) {
		  current = current.getRight();
		}
		// then traverses down until current is the NodeMatrix below the specified
		// coordinates
		// and prev is the NodeMatrix above the specified coordinates
		while (current.getRow() < row) {
			prev = current;
		    current = current.getDown();
		}
		    return prev;
	 }

	 private NodeMatrix<T> findRight(int row, int col) {

	    NodeMatrix<T> current = firstNode;
	    NodeMatrix<T> prev = null;
	    // traverses down across the linked list to the correct row first
	    while (current.getRow() < row) {
	      current = current.getDown();
	    }
	    // then traverses right until current is the NodeMatrix right of the specified
	    // coordinates
	    // and prev is the NodeMatrix left of the specified coordinates
	    while (current.getCol() < col) {
	      prev = current;
	      current = current.getRight();
	    }
	    return prev;
	  }

	 private void deleteRow(int row) {

	    NodeMatrix<T> prev = null;
	    NodeMatrix<T> current = firstNode;
	    // traverses down until current is the row header to be deleted and prev
	    // is the row header after it.
	    while (current.getRow() < row) {
	      prev = current;
	      current = current.getDown();
	    }
	    // bypasses the empty row
	    prev.setDown(current.getDown());
	 }
	 
	 private void deleteCol(int col) {

	    NodeMatrix<T> prev = null;
	    NodeMatrix<T> current = firstNode;
	    // traverses right until current is the column header to be deleted and prev
	    // is the column header after it.
	    while (current.getCol() < col) {
	      prev = current;
	      current = current.getRight();
	    }
	    // bypasses the empty column
	    prev.setRight(current.getRight());
	 }
	 
	 private void createRow(int row) {

	    NodeMatrix<T> previous = null;
	    NodeMatrix<T> current = firstNode;
	    // traverses down until current is the row header to be deleted and prev is the row header after it.
	    while (current.getRow() < row) {
	      previous = current;
	      current = current.getDown();
	    }
	    // creates a new header NodeMatrix that points to a trailer NodeMatrix which points to nothing.
	    previous.setDown(new NodeMatrix(row, 0, current));
	  }
	 
	 private void createCol(int col) {

	    NodeMatrix<T> previous = null;
	    NodeMatrix<T> current = firstNode;
	    // traverses right until current is the column header to be deleted and prev is the column header after it.
	    while (current.getCol() < col) {
	      previous = current;
	      current = current.getRight();
	    }
	    // creates a new header NodeMatrix that points to a trailer NodeMatrix which points to nothing.
	    previous.setRight(new NodeMatrix(0, col, 0));
	  }
	 
	 private boolean isRowEmpty(int row) {
	    boolean rowEmpty = true;
	    NodeMatrix<T> test = firstNode;

	    while (test.getRow() < row) {
	      test = test.getDown();
	    }
	    if (test.getRow() == row);

	    if (test.getRight().getRight() != null) rowEmpty = false;

	    return rowEmpty;
	  }
	 
	 private boolean isColEmpty(int col) {

	    boolean colEmpty = true;
	    NodeMatrix<T> test = firstNode;

	    while (test.getCol() < col) {
	      test = test.getRight();
	    }
	    if (test.getCol() == col);

	    if (test.getDown().getDown() != null) colEmpty = false;

	    return colEmpty;
	  }
	 
	 public String sizeMatrix() {
		 return "Matrix Size: "+lastCol.getCol()+" X "+lastRow.getRow();
	}

}
	
